WooCommerce Automatic SKU Generator
Version 1.1.0

SKU format: SKU-00001, SKU-00002, SKU-00003 ...

INSTALLATION
1. Back up your website.
2. Confirm WooCommerce is installed and active.
3. WordPress Admin > Plugins > Add New Plugin > Upload Plugin.
4. Upload woo-auto-sku-generator.zip, install, and activate.

FEATURES
- Automatically assigns a SKU to a new product if its SKU is blank.
- Automatically assigns a separate SKU to each new variation if blank.
- When a product is duplicated using WooCommerce's built-in Duplicate action,
  the duplicate receives a fresh SKU.
- When a variable product is duplicated, the duplicate parent and its copied
  variations receive fresh SKUs.
- The original product and original variations keep their existing SKUs.
- Existing/manual SKUs are not changed during ordinary product saves.
- Checks WooCommerce for an existing matching SKU before assigning a number.
- Uses sequential format SKU-00001, SKU-00002, and so on.

IMPORTANT
- This version handles WooCommerce's built-in product duplication action.
  Third-party duplication plugins may use a different process and may need
  a compatibility adjustment.
- Existing products with blank SKUs receive an SKU when they are next saved.
- Test duplication of both a simple product and a variable product on a
  staging site before using on a live store.
