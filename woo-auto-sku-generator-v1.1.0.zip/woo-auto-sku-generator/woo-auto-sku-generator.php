<?php
/**
 * Plugin Name: WooCommerce Automatic SKU Generator
 * Description: Generates unique sequential SKUs (SKU-00001) for new products, variations, and duplicated products.
 * Version: 1.1.0
 * Author: Custom
 * Requires Plugins: woocommerce
 * Text Domain: woo-auto-sku-generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WC_Automatic_SKU_Generator {

	const OPTION_COUNTER = 'wc_auto_sku_generator_counter';
	const SKU_PREFIX     = 'SKU-';
	const SKU_DIGITS     = 5;

	public static function init() {
		// Generate an SKU when a product or variation is saved without one.
		add_action( 'woocommerce_new_product', array( __CLASS__, 'maybe_generate_sku' ), 999, 1 );
		add_action( 'woocommerce_update_product', array( __CLASS__, 'maybe_generate_sku' ), 999, 1 );
		add_action( 'woocommerce_new_product_variation', array( __CLASS__, 'maybe_generate_sku' ), 999, 1 );
		add_action( 'woocommerce_update_product_variation', array( __CLASS__, 'maybe_generate_sku' ), 999, 1 );

		// WooCommerce fires this after creating a duplicate product.
		add_action( 'woocommerce_product_duplicate', array( __CLASS__, 'handle_product_duplicate' ), 10, 2 );
	}

	/**
	 * Assign a SKU only when the current SKU is empty.
	 *
	 * @param int $product_id Product or variation ID.
	 */
	public static function maybe_generate_sku( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		if ( '' !== trim( (string) $product->get_sku( 'edit' ) ) ) {
			return;
		}

		self::assign_new_sku( $product );
	}

	/**
	 * When a product is duplicated, give the duplicate a fresh SKU.
	 * For variable products, also regenerate every copied variation SKU.
	 *
	 * The original product and its variations are never modified.
	 *
	 * @param WC_Product $duplicate The newly duplicated product.
	 * @param WC_Product $original  The source product.
	 */
	public static function handle_product_duplicate( $duplicate, $original ) {
		if ( ! $duplicate instanceof WC_Product ) {
			return;
		}

		// Always replace the copied SKU on the duplicate product itself.
		self::assign_new_sku( $duplicate, true );

		// A duplicated variable product may contain copied variation SKUs.
		if ( $duplicate->is_type( 'variable' ) ) {
			$variation_ids = $duplicate->get_children();

			foreach ( $variation_ids as $variation_id ) {
				$variation = wc_get_product( $variation_id );

				if ( $variation instanceof WC_Product_Variation ) {
					self::assign_new_sku( $variation, true );
				}
			}
		}
	}

	/**
	 * Generate and save the next unused SKU.
	 *
	 * @param WC_Product $product       Product or variation.
	 * @param bool       $force_replace Whether to replace an existing SKU.
	 * @return bool
	 */
	private static function assign_new_sku( $product, $force_replace = false ) {
		if ( ! $product instanceof WC_Product ) {
			return false;
		}

		if ( ! $force_replace && '' !== trim( (string) $product->get_sku( 'edit' ) ) ) {
			return false;
		}

		$sku = self::get_next_available_sku();

		if ( ! $sku ) {
			return false;
		}

		try {
			$product->set_sku( $sku );
			$product->save();
			return true;
		} catch ( Exception $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Automatic SKU Generator: ' . $e->getMessage() );
			}
		}

		return false;
	}

	/**
	 * Get the next unused sequential SKU.
	 *
	 * Existing SKUs are checked before assignment, so this can be enabled
	 * on a store that already has products and manually assigned SKUs.
	 *
	 * @return string|false
	 */
	private static function get_next_available_sku() {
		$counter = absint( get_option( self::OPTION_COUNTER, 0 ) );

		for ( $attempt = 0; $attempt < 10000; $attempt++ ) {
			$counter++;
			$sku = self::SKU_PREFIX . str_pad( (string) $counter, self::SKU_DIGITS, '0', STR_PAD_LEFT );

			if ( ! wc_get_product_id_by_sku( $sku ) ) {
				update_option( self::OPTION_COUNTER, $counter, false );
				return $sku;
			}
		}

		return false;
	}
}

add_action( 'plugins_loaded', array( 'WC_Automatic_SKU_Generator', 'init' ) );
